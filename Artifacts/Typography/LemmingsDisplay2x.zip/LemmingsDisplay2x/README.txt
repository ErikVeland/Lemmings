Lemmings Display 2x

A dedicated pixel-art display cut made from the extended Lemmings lettering.
Contours follow the original colour clusters. Letter-specific glints and shade facets refine the doubled pixels.

Contents
- large-blue.png and large-green.png: 32 x 40 cells.
- small-blue.png and small-green.png: 24 x 36 cells.
- large-metrics.json and small-metrics.json: ASCII, extended Latin and the skull.
- preview.png: the display cut on a black background.

Using an atlas
Each glyph record gives its atlas rectangle, draw offsets and advance.
Offsets are relative to the original line origin. Keep negative offsets for accents.
Baseline, ascent, descent and a safe line height are supplied in the metadata.
Use nearest-neighbour sampling. The images have transparent backgrounds and retain the original blue/green colour ramps.

The game uses GameLemmingsDisplayFace with the same doubled advances and bearings.
The runtime retains its existing Tamil forms. These Latin atlas exports do not include the Tamil repertoire.

Regenerate
TEST_SCOPE=typography zsh Scripts/run-app-integration-tests.sh
python3 Tools/Typography/package_display.py
