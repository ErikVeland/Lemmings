Lemmings Countdown 4x

Ten hand-drawn numerals on a 64 x 80 pixel grid.
Each numeral has its own contour, counters, light facet, shade facet and sparkle.
Interior colour clusters come from the original Lemmings large face.

Contents
- blue.png and green.png: transparent atlases for digits 0 through 9.
- metrics.json: atlas rectangles, bearings, advances and baseline.
- preview.png: both colour ramps and the 3, 2, 1 countdown.

Use nearest-neighbour sampling at native size. Bearings and advances are exactly
four times the original large face. The game shares these pixels across Mac,
iOS and TV. GameLemmingsCountdownFace.swift contains the editable drawing data.

Regenerate
TEST_SCOPE=typography zsh Scripts/run-app-integration-tests.sh
python3 Tools/Typography/package_countdown.py
