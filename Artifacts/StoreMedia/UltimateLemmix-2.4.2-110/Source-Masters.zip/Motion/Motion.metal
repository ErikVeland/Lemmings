#include <metal_stdlib>
using namespace metal;
constexpr sampler smoothSampler(coord::normalized,address::clamp_to_edge,filter::linear);
constexpr sampler pixelSampler(coord::normalized,address::clamp_to_edge,filter::nearest);
struct Params { float phase; float sec; uint mode; uint unused; };
constant float tau=6.28318530718;
float bell(float2 uv,float2 centre,float2 radius) {
    float2 q=(uv-centre)/radius;
    return exp(-dot(q,q)*2.0);
}
float rand1(float n){return fract(sin(n*127.1+19.17)*43758.5453);}
float area(float2 uv,float2 centre,float2 radius){
    float2 delta=abs((uv-centre)/radius);
    return 1.-smoothstep(0.72,1.0,max(delta.x,delta.y));
}
float3 stream(texture2d<float,access::sample> base,float2 uv,float phase,float2 drift,float displacement) {
    // Two overlapping advection passes keep the water moving downstream at the loop boundary.
    float a=fract(phase),b=fract(a+0.5);
    float2 wobble=float2(sin(uv.y*103.+tau*phase),cos(uv.x*89.-tau*phase))*displacement;
    float3 p=base.sample(smoothSampler,uv-drift*(a-.5)+wobble).rgb;
    float3 q=base.sample(smoothSampler,uv-drift*(b-.5)+wobble).rgb;
    return mix(p,q,abs(a*2.-1.));
}
float3 pollen(float3 rgb,float2 uv,float phase,bool wide) {
    for(int j=0;j<16;++j) {
        float k=float(j)+1.;
        float f=fract(phase+rand1(k));
        float2 pos=float2(.18+.66*rand1(k+26.),.20+.60*rand1(k+57.));
        pos+=float2(.055*f+.009*sin(tau*(f+rand1(k+8.))),-.12*f);
        float2 v=(uv-pos)*float2(wide?2.333:1.5,1.);
        float r=.0012+.0013*rand1(k+19.);
        float dist=dot(v,v)/(r*r);
        float strength=sin(3.14159*f);
        rgb+=float3(.89,.61,.15)*(.57*exp(-dist)+.1*exp(-dist*.13))*strength*strength;
    }
    return rgb;
}
kernel void film(texture2d<float,access::sample> base [[texture(0)]],
                 texture2d<float,access::sample> actor [[texture(1)]],
                 texture2d<float,access::sample> game [[texture(2)]],
                 texture2d<float,access::write> output [[texture(3)]],
                 constant Params& p [[buffer(0)]],uint2 gid [[thread_position_in_grid]]) {
    float2 size=float2(output.get_width(),output.get_height());
    if(gid.x>=size.x || gid.y>=size.y)return;
    float2 uv=(float2(gid)+.5)/size;
    float theta=tau*p.phase;
    float3 rgb;
    if(p.mode==0) {
        float push=.012*(1.-cos(theta));
        float2 q=(uv-.5)/(1.+push)+.5;
        q.x+=.0035*sin(theta); q.y+=.002*sin(theta);
        float2 original=q;
        float edge=bell(q,float2(.012,.67),float2(.18,.35))+bell(q,float2(.976,.83),float2(.17,.33))+bell(q,float2(.07,.03),float2(.21,.20));
        q+=edge*float2(.0029*sin(theta+q.y*4.),.0025*(cos(theta+q.x*5.)-cos(q.x*5.)));
        float working=area(q,float2(.534,.495),float2(.10,.16));
        float spectator=bell(q,float2(.395,.46),float2(.072,.14));
        float brick=area(q,float2(.581,.595),float2(.053,.034));
        float lift=.5-.5*cos(theta*2.);
        q+=working*float2(.0055*lift,-.012*lift)+spectator*float2(-.003*sin(theta),-.006*lift);
        q.y-=brick*.0085*lift;
        rgb=base.sample(smoothSampler,q).rgb;
        float falling=bell(original,float2(.824,.865),float2(.075,.14));
        float water=clamp(smoothstep(.855,.966,original.y)*smoothstep(.36,.46,original.x)*(1.-smoothstep(.83,.88,original.x))+
            bell(original,float2(.579,.842),float2(.091,.067)),0.,1.);
        rgb=mix(rgb,stream(base,q,p.phase*5.,float2(-.011,.067),.0015),falling*.88);
        rgb=mix(rgb,stream(base,q,p.phase*3.,float2(.021,.020),.0023),water*.76);
        float rays=bell(q,float2(.845,.18),float2(.29,.44));
        rgb*=1.+rays*.043*sin(theta+q.x*8.);
        rgb=pollen(rgb,uv,p.phase,true);
    } else {
        float push=.008*(1.-cos(theta));
        float2 q=(uv-.5)/(1.+push)+.5;
        q.x+=.003*sin(theta);
        float foliage=bell(q,float2(.08,.89),float2(.24,.30))+bell(q,float2(.91,.05),float2(.26,.20));
        q+=foliage*float2(.0027*sin(theta+q.y*4.),.0015*(1.-cos(theta)));
        rgb=base.sample(smoothSampler,q).rgb;
        float waterfall=bell(q,float2(.155,.61),float2(.042,.275));
        rgb=mix(rgb,stream(base,q,p.phase*7.,float2(.002,.052),.001),waterfall*.84);
        float lamp=bell(q,float2(.787,.59),float2(.045,.075));
        rgb*=1.+lamp*.057*sin(theta*3.);
        rgb=pollen(rgb,q,p.phase,false);
        float2 anchor=float2(.511+.045*sin(theta),.498+.033*sin(theta-1.1));
        float ang=.075*sin(theta+.55);
        float2 shape=(q-anchor)*float2(1.5,1.);
        float2 rot=float2(cos(ang)*shape.x+sin(ang)*shape.y,-sin(ang)*shape.x+cos(ang)*shape.y);
        const float height=.324;
        float2 local=rot/float2(height*float(actor.get_width())/float(actor.get_height()),height)+.5;
        if(all(local>=0.) && all(local<=1.)) {
            float4 ink=actor.sample(smoothSampler,local);
            rgb=ink.rgb+rgb*(1.-ink.a);
        }
        // The illustration opens onto the game. A moving camera stays with the airborne actors.
        if(p.sec>2.85 && p.sec<9.35) {
            float t=clamp((p.sec-3.25)/5.65,0.,1.);
            float centreX=66.+15.*smoothstep(.42,1.,t);
            float centreY=58.+65.*smoothstep(.0,1.,t);
            float windowHeight=76.+14.*smoothstep(.48,1.,t);
            float2 level=float2(centreX,centreY)+(uv-.5)*float2(windowHeight*1.5,windowHeight);
            float2 gameUV=level/float2(356.,160.);
            float4 pix=game.sample(pixelSampler,gameUV);
            if(any(gameUV<0.) || any(gameUV>=1.))pix=float4(0.);
            float3 gameColour=pix.rgb;
            // Near-black surround preserves the original clear playfield behind its opaque pixels.
            float3 backdrop=base.sample(smoothSampler,q).rgb;
            float3 shadow=mix(float3(.010,.022,.035),backdrop,.49);
            gameColour+=shadow*(1.-pix.a);
            float opening=min(smoothstep(2.85,3.64,p.sec),1.-smoothstep(8.5,9.35,p.sec));
            float2 d=(uv-float2(.507,.501))*float2(1.5,1.);
            float radius=opening*.99-.05;
            float wipe=1.-smoothstep(radius-.035,radius+.035,length(d));
            rgb=mix(rgb,gameColour,wipe);
        }
    }
    output.write(float4(clamp(rgb,0.,1.),1.),gid);
}
