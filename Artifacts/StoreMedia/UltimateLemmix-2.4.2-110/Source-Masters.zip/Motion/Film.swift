import Foundation
import Metal
import MetalKit
import CoreGraphics
import ImageIO

struct Params { var phase: Float; var sec: Float; var mode: UInt32; var unused: UInt32 = 0 }
let args = CommandLine.arguments
let folder = URL(fileURLWithPath:args[1])
let header = args[2] == "header"
let width = header ? 3840 : 1920, height = header ? 1646 : 1280
let count = header ? 300 : 360
let output = URL(fileURLWithPath:args[3])
let pngOnly = args.contains("--poster")
let device = MTLCreateSystemDefaultDevice()!, queue = device.makeCommandQueue()!
let shader = try String(contentsOf: folder.appendingPathComponent("Motion.metal"),encoding:.utf8)
let library = try device.makeLibrary(source:shader,options:nil)
let pipeline = try device.makeComputePipelineState(function: library.makeFunction(name:"film")!)
let loader=MTKTextureLoader(device:device)
let options: [MTKTextureLoader.Option:Any]=[.SRGB:false,.origin:MTKTextureLoader.Origin.topLeft.rawValue,.textureUsage:MTLTextureUsage.shaderRead.rawValue]
func texture(_ path:String) throws -> MTLTexture {
    try loader.newTexture(URL:folder.appendingPathComponent(path),options:options)
}
let background=try texture(header ? "design/header-4k.png" : "design/search-1920.png")
let actor=try texture("design/search-actor.png")
let descriptor=MTLTextureDescriptor.texture2DDescriptor(pixelFormat:.rgba8Unorm,width:width,height:height,mipmapped:false)
descriptor.usage=[.shaderWrite]
descriptor.storageMode = .shared
let result=device.makeTexture(descriptor:descriptor)!
let pixels=UnsafeMutablePointer<UInt8>.allocate(capacity:width*height*4)
defer { pixels.deallocate() }
var lastTick = -1
var game=try texture("frames/float-070.png")
let file = FileHandle.standardOutput
for i in 0..<(pngOnly ? 1 : count) {
    try autoreleasepool {
        var parameters=Params(phase:Float(i)/Float(count),sec:Float(i)/30,mode:header ? 0 : 1)
        let tick=min(170,max(68,68+Int((Double(i)/30-2.85)*17)))
        if !header && tick != lastTick {
            game=try texture(String(format:"frames/float-%03d.png",tick)); lastTick=tick
        }
        let command=queue.makeCommandBuffer()!, encoder=command.makeComputeCommandEncoder()!
        encoder.setComputePipelineState(pipeline)
        encoder.setTexture(background,index:0);encoder.setTexture(actor,index:1)
        encoder.setTexture(game,index:2);encoder.setTexture(result,index:3)
        encoder.setBytes(&parameters,length:MemoryLayout<Params>.stride,index:0)
        encoder.dispatchThreads(MTLSize(width:width,height:height,depth:1),threadsPerThreadgroup:MTLSize(width:16,height:16,depth:1))
        encoder.endEncoding();command.commit();command.waitUntilCompleted()
        if let error=command.error { throw error }
        result.getBytes(pixels,bytesPerRow:width*4,from:MTLRegionMake2D(0,0,width,height),mipmapLevel:0)
        if pngOnly {
            let data=Data(bytes:pixels,count:width*height*4)
            let space=CGColorSpace(name:CGColorSpace.sRGB)!
            let image=CGImage(width:width,height:height,bitsPerComponent:8,bitsPerPixel:32,bytesPerRow:width*4,space:space,bitmapInfo:CGBitmapInfo(rawValue:CGImageAlphaInfo.noneSkipLast.rawValue),provider:CGDataProvider(data:data as CFData)!,decode:nil,shouldInterpolate:false,intent:.defaultIntent)!
            let destination=CGImageDestinationCreateWithURL(output as CFURL,"public.png" as CFString,1,nil)!
            CGImageDestinationAddImage(destination,image,nil)
            precondition(CGImageDestinationFinalize(destination))
        } else {
            try file.write(contentsOf: Data(bytesNoCopy:pixels,count:width*height*4,deallocator:.none))
        }
    }
}
