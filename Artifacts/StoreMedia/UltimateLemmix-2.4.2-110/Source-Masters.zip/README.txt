Ultimate Lemmix 2.4.2 · Build 110

Art contains four woodland illustrations and a transparent Floater figure. The bridge and Floater illustrations use the established Lemmix mascot as a visual reference. The woodland plate provides the background for the separate umbrella figure.

Captures contains the original game screens from the five device sets. Each file matches the numbered screenshot in the delivery. The second Mac image uses the game's Metal effect over its matching interface capture.

Motion contains the original rendering layers, the Metal animation and the game frames used by the search film. The game advances at 17 ticks per second. The frames are numbered by simulation tick. The two finished films play at 30 frames per second.

Brand contains the build 110 app icon, wordmark, supporting artwork, Archivo typeface and applicable notices. See the main README for each file's placement.
